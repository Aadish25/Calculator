import './App.css'
import Calc from './calc'
function App() {
 
  return (
    <>
    <h1>Calculator</h1>
    <Calc />
      
    </>
  )
}

export default App
